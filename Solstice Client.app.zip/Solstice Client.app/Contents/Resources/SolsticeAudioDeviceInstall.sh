IFS=$''
kextunload /System/Library/Extensions/SolsticeAudioDevice.kext
rm -r /System/Library/Extensions/SolsticeAudioDevice.kext
cp -R $1 /System/Library/Extensions
chmod -R 755 /System/Library/Extensions/SolsticeAudioDevice.kext
chown -R root:wheel /System/Library/Extensions/SolsticeAudioDevice.kext
kextload /System/Library/Extensions/SolsticeAudioDevice.kext

